public class ALU {
    int zr;
    int ng;
    int[] outALU = new int[16];
    int[] b = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
    void ALUFunction(int[] x, int[] y, int zx, int nx, int zy, int ny, int f, int no) {
        //for x
        //Mux16(a=x,b[0..15]=false,sel=zx,out=zdx);
        Mux16 mux16gate2 = new Mux16(); //if 0 dataline1 else if 1, then dataline2
        mux16gate2.Mux16Function(b, x, zx); // b selected
        int[] zdx = new int[16];
        zdx = mux16gate2.muxoutput; // zdx = b

        ////Not16(in=zdx,out=notx);
        Not16 not16gate2 = new Not16();
        not16gate2.Not16Function(zdx);
        int[] notx = new int[16];
        notx = not16gate2.not16output; // not b all 1s
        //Mux16(a=zdx,b=notx,sel=nx,out=ndx);
        Mux16 mux16gate3 = new Mux16();
        mux16gate3.Mux16Function(notx, zdx, nx); // b and not b
        int[] ndx = new int[16];
        ndx = mux16gate3.muxoutput; //notb
        //for y
        Mux16 mux16gate4 = new Mux16();
        mux16gate4.Mux16Function(b, y, zy); //b
        int[] zdy = new int[16];
        zdy = mux16gate4.muxoutput; //b
        Not16 not16gate3 = new Not16();
        not16gate3.Not16Function(zdy); // not b
        int[] noty = new int[16];
        noty = not16gate3.not16output;
        //System.out.print(noty);
        Mux16 mux16gate5 = new Mux16();
        mux16gate5.Mux16Function(noty, zdy, ny); //notb
        int[] ndy = new int[16];
        ndy = mux16gate5.muxoutput;
        //And or (Add)
        Add16 add16gate2 = new Add16();
        add16gate2.Add16Function(ndx, ndy);
        int[] xplusy = new int[16];
        xplusy = add16gate2.sumAdd; //not b + not b
        //System.out.print(xplusy);
        //(And)
        And16 and16gate2 = new And16();
        and16gate2.And16Function(ndx, ndy); //not ba dn not b
        int[] xandy = new int[16];
        xandy = and16gate2.andout;
        //mux to choose
        Mux16 mux16gate6 = new Mux16();
        mux16gate6.Mux16Function(xplusy, xandy, f); // xplusy aka not b+notb
        int[] fxy = new int[16];
        fxy = mux16gate6.muxoutput;
        //the output or not output
        Not16 not16gate4 = new Not16();
        not16gate4.Not16Function(fxy); //notnotb aka all0s
        int[] nfxy = new int[16];
        nfxy = not16gate4.not16output;
        //choosing between output or not output
        Mux16 mux16gate7 = new Mux16();
        mux16gate7.Mux16Function(nfxy, fxy, no); //all 0s nfxy notnotb, if no is 1, it picks nfxy, if 0 fxy:
        int[] oo = new int[16];
        oo = mux16gate7.muxoutput;
        ng = mux16gate7.muxoutput[15];
        //or16way aka bad variable names
        Or16Way or16waygate0 = new Or16Way();
        or16waygate0.Or16WayFunction(oo);
        int o = or16waygate0.or16wayout;//0
        //not gate why no one knows
        Not notgate20 = new Not();
        notgate20.NotFunction(o);
        zr = notgate20.out10;//1 1 if oo = 0
        //System.out.print(zr);
        //And
        //And16 and16gate30 = new And16();
        //int[] inputa = {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1};
        //and16gate30.And16Function(inputa, oo); //b
        //ng = and16gate30.andout[15]; // andout[0..14] drops we won't use // ans 0
        //System.out.print(ng); // if oo > 0 at least 1
        //Or
       // Or16 or16gate1 = new Or16();
        //int[] b2 = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
        //or16gate1.Or16Function(oo,b2);
        //outALU = or16gate1.or16out;
        outALU = mux16gate7.muxoutput;
        for(int i=0; i<=15; i++) {
            System.out.print(outALU[i]);
        }
    }
    public static void main(String[] args) {
        ALU alu0 = new ALU();
        int[] xinput = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
        int[] yinput = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1};
        alu0.ALUFunction(xinput,yinput,0,1,1,1,1,1);
        System.out.println("ng"+alu0.ng);
        System.out.println("zr"+alu0.zr);
    }
}

