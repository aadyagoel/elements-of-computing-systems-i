/*public class ARegister {
    int[] value = new int[15];
    void ARegisterFunction(int[] Ainstructionin) {
        int opcode = Ainstructionin[0];
        for(int i = 0; i<=14; i++){
            value[i] = Ainstructionin[i];
        }
    }

    /*public static void main(String[] args) {
        ARegister a = new ARegister();
        int[] b = {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1};
        a.ARegisterFunction(b);
        for(int i =0; i<=14; i++) {
            System.out.print(a.value[i]);
       } }
}*/
//load?
//if opcode 0 A instruction from instruction
// if opcode 1 C instruction from ALU output