/*public class DMux8Way {
    int a, b, c, d, e, f, g, h;
    void DMux8WayFunction(int dmuxload, int dmuxsel) {

    }
}
*/