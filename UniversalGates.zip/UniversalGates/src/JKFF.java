/*public class JKFF {
    //CHIP JKFF {
    //    IN J, K;
    //    OUT Q, nQ;
    //
    //    PARTS:
    //    Not(in=K, out=notK);
    //    And (a=J, b=nQ1, out=in1);
    //    And (a=notK, b=Q1, out=in2);
    //    Or (a=in1, b=in2, out=orout);
    //    DFF(in=orout,out=Q,out=Q1);
    //    Not(in=Q1,out=nQ,out=nQ1);
    //
    int Q;
    int nQ;

    void JKFFFunction(int J, int K) {
        Not notgate10 = new Not();
        notgate10.NotFunction(J);
        int notK = notgate10.out10;

        And andgate10 = new And();
        andgate10.AndFunction(J, Q1);

    }

}
*/