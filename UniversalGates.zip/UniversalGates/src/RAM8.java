/*public class RAM8 {
    //CHIP RAM8 {
    //    IN in[16], load, address[3];
    //    OUT out[16];
    //
    //    PARTS:
    //DMux8Way(in=load,sel=address,a=a,b=b,c=c,d=d,e=e,f=f,g=g,h=h);
    //
    //Register(in=in,load=a,out=oa);
    //Register(in=in,load=b,out=ob);
    //Register(in=in,load=c,out=oc);
    //Register(in=in,load=d,out=od);
    //Register(in=in,load=e,out=oe);
    //Register(in=in,load=f,out=of);
    //Register(in=in,load=g,out=og);
    //Register(in=in,load=h,out=oh);
    //
    //Mux8Way16(a=oa,b=ob,c=oc,d=od,e=oe,f=of,g=og,h=oh,sel=address,out=out);
    int RAM8out;
    void RAM8Function(int[] ram8in, int ram8load, int[] address){

        Register16 register16gate1 = new Register16;
        register16gate1.Register16Function(ram8in,);
    }

}
*/
