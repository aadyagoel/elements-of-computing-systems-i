public class Register16 {
    int[] register16out = new int[16];
    void Register16Function(int[] register16in, int r16load) {
        Register register1 = new Register();
        for(int i = 0; i<=15; i++) {
            register1.RegisterFunction(register16in[i],r16load);
            register16out[i] = register1.registerout;
        }
    }
}
