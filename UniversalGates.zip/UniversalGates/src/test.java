/*public class test extends MuxTwoOne {
    int[] muxoutput = new int[16];


    void Mux16Function(int[] dataline1, int[] dataline2,int sel) {
        for(int i=0;i<=15;i++) {
            muxoutput[i] = MuxFunction(dataline1[i],dataline2[i],sel);
            //MuxTwoOne mux1 = new MuxTwoOne();
            //mux1.MuxFunction(dataline1[i],dataline2[i],sel);
            //muxoutput[i] = mux1.out17;
            //System.out.print(mux1.out17);
            System.out.print(muxoutput[i]);
        }
    }
    public static void main(String[] args) {
        test mux161 = new test();
        int[] dataline1 = new int[16];
        int[] dataline2 = new int[16];
        int[] dataline11 = {0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1};
        int[] dataline12 = {0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1};

        mux161.Mux16Function(dataline11,dataline12,1);
        //for(int i=0;i>=15;i++) {
        //  System.out.print(mux161.muxoutput[i]);
        //}
    }
}

 */
